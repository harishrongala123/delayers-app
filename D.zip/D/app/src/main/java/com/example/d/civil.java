package com.example.d;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class civil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civil);
    }

    public void insertcivil(View view) {
        Intent intent = new Intent(civil.this, civilAdd.class);
        startActivity(intent);
    }

    public void viewcivil(View view) {
        Intent intent = new Intent(civil.this, civilView.class);
        startActivity(intent);
    }
}
