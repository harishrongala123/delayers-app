package com.example.d;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class civilView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civil_view);
    }
}
