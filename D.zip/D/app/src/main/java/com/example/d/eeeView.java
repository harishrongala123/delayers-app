package com.example.d;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class eeeView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eee_view);
    }
}
